# Qalqon — qoʻngʻiroq bloklagich

APK'ni GitHub oʻzi yigʻadi (Android Studio kerak emas):

1. GitHub'da yangi (boʻsh) repository oching.
2. Shu papkadagi **barcha fayllarni** (yashirin `.github` papkasi bilan) yuklang.
3. Repository'da **Actions** boʻlimiga kiring. "Build APK" ishga tushadi (5–10 daqiqa).
   Agar oʻzi boshlanmasa: Actions → Build APK → **Run workflow**.
4. Tugagach, ish sahifasi pastidagi **Artifacts → Qalqon-debug-apk** ni yuklab oling,
   ZIP ichidagi `app-debug.apk` ni telefonga oʻrnating.
5. Ilovani ochib, **"Qoʻngʻiroq filtri qilib tanlash"** tugmasini bosing — shundan keyin bloklash ishlaydi.

Xato chiqsa, Actions'dagi qizil bosqichning matnini nusxalab yuboring.
