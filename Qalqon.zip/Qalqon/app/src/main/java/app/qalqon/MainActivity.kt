package app.qalqon

import android.Manifest
import android.app.TimePickerDialog
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.materialswitch.MaterialSwitch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var content: FrameLayout
    private var tab = R.id.nav_home
    private var pendingWhite = false

    // ---------- activity result launchers ----------
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { render() }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { render() }

    private val contactLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uri = res.data?.data
            if (uri != null) {
                try {
                    contentResolver.query(
                        uri,
                        arrayOf(
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                        ),
                        null, null, null
                    )?.use { c ->
                        if (c.moveToFirst()) saveRule(c.getString(0), c.getString(1), Matcher.EXACT, pendingWhite)
                    }
                } catch (e: Exception) {
                    toast(R.string.file_error)
                }
            }
            render()
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) importFrom(uri, pendingWhite)
            render()
        }

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
            if (uri != null) exportTo(uri, pendingWhite)
        }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tab = savedInstanceState?.getInt("tab") ?: R.id.nav_home
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val nav = BottomNavigationView(this)
        nav.inflateMenu(R.menu.bottom_nav)
        nav.setOnItemSelectedListener {
            tab = it.itemId
            render()
            true
        }
        nav.selectedItemId = tab
        root.addView(nav, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(root)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("tab", tab)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        content.removeAllViews()
        val page = when (tab) {
            R.id.nav_home -> homePage()
            R.id.nav_black -> listPage(false)
            R.id.nav_white -> listPage(true)
            R.id.nav_log -> logPage()
            else -> settingsPage()
        }
        content.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------- small UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun scale(): Float =
        floatArrayOf(0.85f, 1f, 1.15f, 1.3f)[Prefs.int(this, Prefs.FONT, 1).coerceIn(0, 3)]

    private fun color(attr: Int, fallback: Int) = MaterialColors.getColor(this, attr, fallback)
    private fun onSurface() = color(com.google.android.material.R.attr.colorOnSurface, Color.BLACK)
    private fun variant() = color(com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

    private fun tv(s: CharSequence, sp: Float = 15f, bold: Boolean = false, c: Int = onSurface()): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * scale())
        t.setTextColor(c)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun selectable(v: View) {
        val t = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, t, true)
        v.setBackgroundResource(t.resourceId)
    }

    private fun pageTitle(res: Int): TextView {
        val t = tv(getString(res), 28f, true)
        t.setPadding(dp(16), dp(20), dp(16), dp(8))
        return t
    }

    private fun section(res: Int): TextView {
        val t = tv(getString(res), 13f, true, color(com.google.android.material.R.attr.colorPrimary, Color.BLUE))
        t.setPadding(dp(4), dp(20), dp(4), dp(4))
        return t
    }

    private fun outlined(text: String, onClick: () -> Unit): MaterialButton {
        val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        b.text = text
        b.setOnClickListener { onClick() }
        return b
    }

    private fun switchRow(label: Int, desc: Int?, key: String, def: Boolean, after: ((Boolean) -> Unit)? = null): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        val left = vbox()
        left.addView(tv(getString(label), 16f))
        if (desc != null) left.addView(tv(getString(desc), 13f, false, variant()))
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = MaterialSwitch(this)
        sw.isChecked = Prefs.bool(this, key, def)
        sw.setOnCheckedChangeListener { _, b ->
            Prefs.setBool(this, key, b)
            after?.invoke(b)
        }
        row.addView(sw)
        return row
    }

    private fun actionRow(label: Int, desc: String?, onClick: () -> Unit): View {
        val row = vbox()
        row.setPadding(dp(4), dp(12), dp(4), dp(12))
        selectable(row)
        row.addView(tv(getString(label), 16f))
        if (!desc.isNullOrEmpty()) row.addView(tv(desc, 13f, false, variant()))
        row.setOnClickListener { onClick() }
        return row
    }

    private fun confirm(msg: String, yes: () -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setMessage(msg)
            .setPositiveButton(R.string.delete) { _, _ -> yes() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun matchLabel(m: Int) = getString(
        when (m) {
            Matcher.STARTS -> R.string.match_starts
            Matcher.CONTAINS -> R.string.match_contains
            else -> R.string.match_exact
        }
    )

    private fun reasonLabel(r: String) = getString(
        when (r) {
            Matcher.R_PRIVATE -> R.string.reason_private
            Matcher.R_UNKNOWN -> R.string.reason_unknown
            else -> R.string.reason_list
        }
    )

    // ---------- role (call filter app) ----------
    private fun roleHeld(): Boolean {
        val rm = getSystemService(RoleManager::class.java) ?: return false
        return rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    }

    private fun requestRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
        } else {
            toast(R.string.role_unavailable)
        }
    }

    private fun has(perm: String) = checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    // ======================= HOME =======================
    private fun homePage(): View {
        val sv = ScrollView(this)
        val col = vbox()
        col.setPadding(dp(16), dp(20), dp(16), dp(24))
        sv.addView(col)
        col.addView(tv(getString(R.string.app_name), 28f, true))

        val held = roleHeld()
        val enabled = Prefs.bool(this, Prefs.ENABLED, true)
        val pauseUntil = Prefs.long(this, Prefs.PAUSE_UNTIL, 0L)
        val paused = pauseUntil > System.currentTimeMillis()
        val scheduled = Prefs.bool(this, Prefs.SCHEDULE, false)
        val offBySchedule = scheduled && !Matcher.scheduleActive(this)
        val active = held && enabled && !paused && !offBySchedule

        val statusText = when {
            !held -> getString(R.string.status_no_role)
            !enabled -> getString(R.string.status_off)
            paused -> getString(R.string.status_paused, SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(pauseUntil)))
            offBySchedule -> getString(R.string.status_schedule_off)
            else -> getString(R.string.status_on)
        }

        val primary = color(com.google.android.material.R.attr.colorPrimary, Color.BLUE)
        val onPrimary = color(com.google.android.material.R.attr.colorOnPrimary, Color.WHITE)
        val surfaceVar = color(com.google.android.material.R.attr.colorSurfaceVariant, Color.LTGRAY)
        val fg = if (active) onPrimary else onSurface()

        val card = MaterialCardView(this)
        card.radius = dp(24).toFloat()
        card.cardElevation = 0f
        card.setCardBackgroundColor(if (active) primary else surfaceVar)
        val inner = vbox()
        inner.setPadding(dp(24), dp(24), dp(24), dp(24))
        inner.addView(tv(statusText, 22f, true, fg))
        if (!held) {
            val b = MaterialButton(this)
            b.setText(R.string.btn_enable_role)
            b.setOnClickListener { requestRole() }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.topMargin = dp(16)
            inner.addView(b, lp)
        } else {
            val sw = MaterialSwitch(this)
            sw.isChecked = enabled
            sw.setOnCheckedChangeListener { _, b ->
                Prefs.setBool(this, Prefs.ENABLED, b)
                render()
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.topMargin = dp(12)
            inner.addView(sw, lp)
        }
        card.addView(inner)
        val clp = LinearLayout.LayoutParams(MATCH, WRAP)
        clp.topMargin = dp(16)
        col.addView(card, clp)

        val db = Db.get(this)
        val startOfDay = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val stats = tv(getString(R.string.blocked_stats, db.countLog(startOfDay), db.countLog(0L)), 14f, false, variant())
        stats.setPadding(dp(4), dp(12), dp(4), 0)
        col.addView(stats)

        // pause
        col.addView(section(R.string.pause_title))
        val prow = LinearLayout(this)
        prow.orientation = LinearLayout.HORIZONTAL
        fun addBtn(label: Int, ms: Long) {
            val b = outlined(getString(label)) { pauseFor(ms) }
            val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
            lp.rightMargin = dp(8)
            prow.addView(b, lp)
        }
        addBtn(R.string.pause_1h, 60L * 60 * 1000)
        addBtn(R.string.pause_8h, 8L * 60 * 60 * 1000)
        val tomorrow = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }.timeInMillis
        addBtn(R.string.pause_tomorrow, tomorrow - System.currentTimeMillis())
        col.addView(prow)
        if (paused) {
            val b = MaterialButton(this)
            b.setText(R.string.pause_resume)
            b.setOnClickListener {
                Prefs.setLong(this, Prefs.PAUSE_UNTIL, 0L)
                render()
            }
            val lp = LinearLayout.LayoutParams(MATCH, WRAP)
            lp.topMargin = dp(8)
            col.addView(b, lp)
        }

        // options
        col.addView(section(R.string.sec_rules))
        col.addView(switchRow(R.string.opt_private, R.string.opt_private_desc, Prefs.PRIVATE, false))
        col.addView(switchRow(R.string.opt_unknown, R.string.opt_unknown_desc, Prefs.UNKNOWN, false) { on ->
            if (on && !has(Manifest.permission.READ_CONTACTS)) permLauncher.launch(arrayOf(Manifest.permission.READ_CONTACTS))
        })
        col.addView(switchRow(R.string.opt_silence, R.string.opt_silence_desc, Prefs.SILENCE, false))
        col.addView(switchRow(R.string.opt_hide, R.string.opt_hide_desc, Prefs.HIDE, false))
        col.addView(switchRow(R.string.opt_notify, null, Prefs.NOTIFY, true) { on ->
            if (on && Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            }
        })
        return sv
    }

    private fun pauseFor(ms: Long) {
        Prefs.setLong(this, Prefs.PAUSE_UNTIL, System.currentTimeMillis() + ms)
        render()
    }

    // ======================= LISTS =======================
    private fun listPage(white: Boolean): View {
        val frame = FrameLayout(this)
        val col = vbox()

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = tv(getString(if (white) R.string.tab_white else R.string.tab_black), 28f, true)
        title.setPadding(dp(16), dp(20), dp(8), dp(8))
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val more = tv("⋮", 26f, true)
        more.setPadding(dp(16), dp(16), dp(16), dp(4))
        more.setOnClickListener { v ->
            val pm = PopupMenu(this, v)
            pm.menu.add(0, 1, 0, R.string.menu_export)
            pm.menu.add(0, 2, 1, R.string.menu_import)
            pm.menu.add(0, 3, 2, R.string.menu_clear)
            pm.setOnMenuItemClickListener { item ->
                pendingWhite = white
                when (item.itemId) {
                    1 -> exportLauncher.launch(if (white) "qalqon_whitelist.csv" else "qalqon_blacklist.csv")
                    2 -> importLauncher.launch(arrayOf("*/*"))
                    3 -> confirm(getString(R.string.delete_all_q)) {
                        Db.get(this).clearRules(white)
                        render()
                    }
                }
                true
            }
            pm.show()
        }
        header.addView(more)
        col.addView(header)

        val items = Db.get(this).rules(white)
        if (items.isEmpty()) {
            val e = tv(getString(if (white) R.string.list_white_empty else R.string.list_black_empty), 15f, false, variant())
            e.gravity = Gravity.CENTER
            e.setPadding(dp(32), dp(48), dp(32), 0)
            col.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
        } else {
            val lv = ListView(this)
            lv.divider = null
            lv.clipToPadding = false
            lv.setPadding(0, 0, 0, dp(96))
            lv.adapter = object : BaseAdapter() {
                override fun getCount() = items.size
                override fun getItem(position: Int): Any = items[position]
                override fun getItemId(position: Int): Long = items[position].id
                override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = ruleRow(items[position])
            }
            lv.setOnItemClickListener { _, _, pos, _ ->
                val r = items[pos]
                confirm(getString(R.string.delete_rule_q, r.number)) {
                    Db.get(this).deleteRule(r.id)
                    render()
                }
            }
            col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        frame.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        val fab = FloatingActionButton(this)
        fab.setImageResource(R.drawable.ic_add)
        fab.contentDescription = getString(R.string.add_title)
        fab.setOnClickListener { addDialog(white) }
        val flp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.BOTTOM)
        flp.setMargins(0, 0, dp(16), dp(16))
        frame.addView(fab, flp)
        return frame
    }

    private fun ruleRow(r: Rule): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(16), dp(10), dp(16), dp(10))
        row.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        val left = vbox()
        left.addView(tv(r.number, 17f, true))
        val sub = matchLabel(r.mtype) + (if (r.name.isNullOrBlank()) "" else " · " + r.name)
        left.addView(tv(sub, 13f, false, variant()))
        row.addView(left, LinearLayout.LayoutParams(0, WRAP, 1f))
        val sw = MaterialSwitch(this)
        sw.isChecked = r.enabled
        sw.setOnCheckedChangeListener { _, b -> Db.get(this).setRuleEnabled(r.id, b) }
        row.addView(sw)
        return row
    }

    private fun addDialog(white: Boolean) {
        pendingWhite = white
        val opts = arrayOf(
            getString(R.string.add_manual),
            getString(R.string.add_contact),
            getString(R.string.add_calllog),
            getString(R.string.add_file)
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_title)
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> manualDialog(white, null)
                    1 -> contactLauncher.launch(
                        Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
                    )
                    2 -> callLogDialog(white)
                    3 -> importLauncher.launch(arrayOf("*/*"))
                }
            }
            .show()
    }

    private fun manualDialog(white: Boolean, prefill: String?) {
        val box = vbox()
        box.setPadding(dp(24), dp(8), dp(24), 0)
        val num = EditText(this)
        num.hint = getString(R.string.hint_number)
        num.inputType = InputType.TYPE_CLASS_PHONE
        if (prefill != null) num.setText(prefill)
        val name = EditText(this)
        name.hint = getString(R.string.hint_name)
        val rg = RadioGroup(this)
        val ids = IntArray(3) { View.generateViewId() }
        val labels = intArrayOf(R.string.match_exact, R.string.match_starts, R.string.match_contains)
        for (i in 0..2) {
            val rb = RadioButton(this)
            rb.id = ids[i]
            rb.setText(labels[i])
            rg.addView(rb)
        }
        rg.check(ids[0])
        box.addView(num)
        box.addView(name)
        box.addView(rg)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_manual)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                val m = ids.indexOf(rg.checkedRadioButtonId).coerceAtLeast(0)
                saveRule(num.text.toString(), name.text.toString(), m, white)
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun saveRule(number: String?, name: String?, mtype: Int, white: Boolean) {
        val n = number?.trim().orEmpty()
        if (Matcher.norm(n).isEmpty()) {
            toast(R.string.invalid_number)
            return
        }
        if (!Db.get(this).addRule(n, name, mtype, white)) toast(R.string.duplicate)
    }

    private fun callLogDialog(white: Boolean) {
        if (!has(Manifest.permission.READ_CALL_LOG)) {
            permLauncher.launch(arrayOf(Manifest.permission.READ_CALL_LOG))
            toast(R.string.perm_needed)
            return
        }
        val nums = ArrayList<String>()
        val names = ArrayList<String?>()
        val labels = ArrayList<String>()
        try {
            contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
                null, null, CallLog.Calls.DATE + " DESC"
            )?.use { c ->
                val seen = HashSet<String>()
                while (c.moveToNext() && nums.size < 100) {
                    val n = c.getString(0)
                    if (n.isNullOrBlank() || !seen.add(n)) continue
                    val nm = c.getString(1)
                    nums.add(n)
                    names.add(nm)
                    labels.add(if (nm.isNullOrBlank()) n else "$nm  ($n)")
                }
            }
        } catch (e: Exception) {
            toast(R.string.file_error)
            return
        }
        val checked = BooleanArray(nums.size)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_calllog)
            .setMultiChoiceItems(labels.toTypedArray(), checked) { _, i, b -> checked[i] = b }
            .setPositiveButton(R.string.save) { _, _ ->
                for (i in nums.indices) if (checked[i]) saveRule(nums[i], names[i], Matcher.EXACT, white)
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---------- import / export ----------
    private fun importFrom(uri: Uri, white: Boolean) {
        var added = 0
        val db = Db.get(this)
        try {
            val sdb = db.writableDatabase
            sdb.beginTransaction()
            try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { r ->
                    r.forEachLine { line ->
                        val p = line.split(',', ';', '\t')
                        val num = p[0].trim()
                        if (Matcher.norm(num).isNotEmpty() && num.length <= 32) {
                            val name = if (p.size > 1) p[1].trim() else null
                            val m = if (p.size > 2) (p[2].trim().toIntOrNull() ?: 0).coerceIn(0, 2) else 0
                            if (db.addRule(num, name, m, white)) added++
                        }
                    }
                }
                sdb.setTransactionSuccessful()
            } finally {
                sdb.endTransaction()
            }
            toast(getString(R.string.added_n, added))
        } catch (e: Exception) {
            toast(R.string.file_error)
        }
    }

    private fun csv(s: String) = s.replace(',', ' ').replace('\n', ' ')

    private fun exportTo(uri: Uri, white: Boolean) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { w ->
                for (r in Db.get(this).rules(white).reversed()) {
                    w.write("${csv(r.number)},${csv(r.name ?: "")},${r.mtype}\n")
                }
            }
            toast(R.string.exported)
        } catch (e: Exception) {
            toast(R.string.file_error)
        }
    }

    // ======================= LOG =======================
    private fun logPage(): View {
        val col = vbox()
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = tv(getString(R.string.tab_log), 28f, true)
        title.setPadding(dp(16), dp(20), dp(8), dp(8))
        header.addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
        val items = Db.get(this).logs()
        if (items.isNotEmpty()) {
            val clear = outlined(getString(R.string.log_clear)) {
                Db.get(this).clearLog()
                render()
            }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.rightMargin = dp(16)
            header.addView(clear, lp)
        }
        col.addView(header)

        if (items.isEmpty()) {
            val e = tv(getString(R.string.log_empty), 15f, false, variant())
            e.gravity = Gravity.CENTER
            e.setPadding(dp(32), dp(48), dp(32), 0)
            col.addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
            return col
        }
        val fmt = SimpleDateFormat("dd.MM  HH:mm", Locale.getDefault())
        val lv = ListView(this)
        lv.divider = null
        lv.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int): Any = items[position]
            override fun getItemId(position: Int): Long = items[position].id
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val it = items[position]
                val row = vbox()
                row.setPadding(dp(16), dp(10), dp(16), dp(10))
                val n = if (it.number.isNullOrBlank()) getString(R.string.private_number) else it.number
                row.addView(tv(n, 17f, true))
                row.addView(tv(reasonLabel(it.reason) + " · " + fmt.format(Date(it.time)), 13f, false, variant()))
                return row
            }
        }
        lv.setOnItemClickListener { _, _, pos, _ ->
            val it = items[pos]
            if (!it.number.isNullOrBlank()) {
                MaterialAlertDialogBuilder(this)
                    .setTitle(it.number)
                    .setItems(arrayOf(getString(R.string.log_add_white))) { _, _ ->
                        saveRule(it.number, null, Matcher.EXACT, true)
                        toast(R.string.saved)
                    }
                    .show()
            }
        }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return col
    }

    // ======================= SETTINGS =======================
    private fun settingsPage(): View {
        val sv = ScrollView(this)
        val col = vbox()
        col.setPadding(dp(16), 0, dp(16), dp(24))
        sv.addView(col)
        col.addView(pageTitle(R.string.tab_settings).also { it.setPadding(0, dp(20), 0, dp(8)) })

        col.addView(actionRow(R.string.role_title, getString(if (roleHeld()) R.string.role_ok else R.string.role_not_ok)) {
            if (!roleHeld()) requestRole()
        })

        col.addView(section(R.string.sec_schedule))
        col.addView(switchRow(R.string.opt_schedule, R.string.opt_schedule_desc, Prefs.SCHEDULE, false))
        col.addView(actionRow(R.string.manage_periods, getString(R.string.manage_periods_desc)) { scheduleDialog() })

        col.addView(section(R.string.sec_look))
        val themeNames = arrayOf(getString(R.string.theme_system), getString(R.string.theme_light), getString(R.string.theme_dark))
        col.addView(actionRow(R.string.theme, themeNames[Prefs.int(this, Prefs.THEME, 0).coerceIn(0, 2)]) { themeDialog(themeNames) })
        val fontNames = arrayOf(getString(R.string.font_s), getString(R.string.font_m), getString(R.string.font_l), getString(R.string.font_xl))
        col.addView(actionRow(R.string.font_size, fontNames[Prefs.int(this, Prefs.FONT, 1).coerceIn(0, 3)]) { fontDialog(fontNames) })

        col.addView(section(R.string.sec_about))
        col.addView(tv(getString(R.string.about_text), 14f, false, variant()).also { it.setPadding(dp(4), dp(8), dp(4), 0) })
        return sv
    }

    private fun themeDialog(names: Array<String>) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.theme)
            .setSingleChoiceItems(names, Prefs.int(this, Prefs.THEME, 0)) { d, w ->
                Prefs.setInt(this, Prefs.THEME, w)
                d.dismiss()
                App.applyTheme(this)
                render()
            }
            .show()
    }

    private fun fontDialog(names: Array<String>) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.font_size)
            .setSingleChoiceItems(names, Prefs.int(this, Prefs.FONT, 1)) { d, w ->
                Prefs.setInt(this, Prefs.FONT, w)
                d.dismiss()
                render()
            }
            .show()
    }

    // ---------- schedule ----------
    private fun calDay(i: Int) = if (i == 6) 1 else i + 2 // list index (Mon..Sun) -> Calendar day
    private fun dayIndex(day: Int) = if (day == 1) 6 else day - 2

    private fun hhmm(min: Int) = String.format(Locale.US, "%02d:%02d", min / 60, min % 60)

    private fun scheduleDialog() {
        val days = resources.getStringArray(R.array.days)
        val periods = Db.get(this).periods()
        val labels = ArrayList<String>()
        for (p in periods) labels.add(days[dayIndex(p.day)] + "   " + hhmm(p.startMin) + " – " + hhmm(p.endMin))
        labels.add(getString(R.string.add_period))
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.manage_periods)
            .setItems(labels.toTypedArray()) { _, w ->
                if (w == periods.size) {
                    addPeriodFlow()
                } else {
                    val p = periods[w]
                    confirm(getString(R.string.delete_rule_q, labels[w])) {
                        Db.get(this).deletePeriod(p.id)
                        scheduleDialog()
                    }
                }
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun addPeriodFlow() {
        val days = resources.getStringArray(R.array.days)
        val checked = BooleanArray(7)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.pick_days)
            .setMultiChoiceItems(days, checked) { _, i, b -> checked[i] = b }
            .setPositiveButton(R.string.next) { _, _ ->
                if (checked.any { it }) {
                    pickTime(R.string.start_time, 22, 0) { s ->
                        pickTime(R.string.end_time, 7, 0) { e ->
                            if (s != e) for (i in 0..6) if (checked[i]) Db.get(this).addPeriod(calDay(i), s, e)
                            scheduleDialog()
                        }
                    }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun pickTime(titleRes: Int, h: Int, m: Int, done: (Int) -> Unit) {
        val d = TimePickerDialog(this, { _, hh, mm -> done(hh * 60 + mm) }, h, m, true)
        d.setTitle(titleRes)
        d.show()
    }
}
