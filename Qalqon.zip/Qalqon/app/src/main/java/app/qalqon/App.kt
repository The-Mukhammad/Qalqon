package app.qalqon

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        applyTheme(this)
    }

    companion object {
        fun applyTheme(c: Context) {
            AppCompatDelegate.setDefaultNightMode(
                when (Prefs.int(c, Prefs.THEME, 0)) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
