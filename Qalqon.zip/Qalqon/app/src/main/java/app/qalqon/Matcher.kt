package app.qalqon

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.util.Calendar

class Decision(val block: Boolean, val reason: String)

object Matcher {
    const val EXACT = 0
    const val STARTS = 1
    const val CONTAINS = 2

    const val R_PRIVATE = "private"
    const val R_LIST = "list"
    const val R_UNKNOWN = "unknown"

    /** Keeps digits only, so "+998 (90) 123-45-67" and "998901234567" compare equal. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s) if (ch in '0'..'9') sb.append(ch)
        return sb.toString()
    }

    fun matches(rule: Rule, number: String): Boolean {
        val n = norm(number)
        val p = norm(rule.number)
        if (n.isEmpty() || p.isEmpty()) return false
        return when (rule.mtype) {
            STARTS -> n.startsWith(p)
            CONTAINS -> n.contains(p)
            else -> n == p || (minOf(n.length, p.length) >= 7 && (n.endsWith(p) || p.endsWith(n)))
        }
    }

    fun decide(c: Context, number: String?): Decision {
        if (!Prefs.bool(c, Prefs.ENABLED, true)) return Decision(false, "")
        if (Prefs.long(c, Prefs.PAUSE_UNTIL, 0L) > System.currentTimeMillis()) return Decision(false, "")
        if (Prefs.bool(c, Prefs.SCHEDULE, false) && !scheduleActive(c)) return Decision(false, "")

        if (number.isNullOrBlank()) {
            return if (Prefs.bool(c, Prefs.PRIVATE, false)) Decision(true, R_PRIVATE) else Decision(false, "")
        }
        val db = Db.get(c)
        if (db.rules(true, true).any { matches(it, number) }) return Decision(false, "")
        if (db.rules(false, true).any { matches(it, number) }) return Decision(true, R_LIST)
        if (Prefs.bool(c, Prefs.UNKNOWN, false) && !inContacts(c, number)) return Decision(true, R_UNKNOWN)
        return Decision(false, "")
    }

    /** Returns true when we cannot check (no permission), so nobody gets blocked by mistake. */
    private fun inContacts(c: Context, number: String): Boolean {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return true
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            c.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
                ?.use { it.count > 0 } ?: true
        } catch (e: Exception) {
            true
        }
    }

    /** Is "now" inside one of the user's blocking periods? Periods may cross midnight. */
    fun scheduleActive(c: Context): Boolean {
        val cal = Calendar.getInstance()
        val day = cal.get(Calendar.DAY_OF_WEEK)
        val prev = if (day == 1) 7 else day - 1
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        for (p in Db.get(c).periods()) {
            if (!p.enabled) continue
            if (p.startMin <= p.endMin) {
                if (p.day == day && now >= p.startMin && now < p.endMin) return true
            } else {
                if (p.day == day && now >= p.startMin) return true
                if (p.day == prev && now < p.endMin) return true
            }
        }
        return false
    }
}
