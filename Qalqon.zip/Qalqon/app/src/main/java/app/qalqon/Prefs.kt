package app.qalqon

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val ENABLED = "enabled"
    const val PRIVATE = "block_private"
    const val UNKNOWN = "block_unknown"
    const val SILENCE = "silence_only"
    const val HIDE = "hide_blocked"
    const val NOTIFY = "notify"
    const val SCHEDULE = "schedule_on"
    const val PAUSE_UNTIL = "pause_until"
    const val THEME = "theme"
    const val FONT = "font"

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("qalqon", Context.MODE_PRIVATE)

    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)
    fun setInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun long(c: Context, k: String, d: Long): Long = sp(c).getLong(k, d)
    fun setLong(c: Context, k: String, v: Long) = sp(c).edit().putLong(k, v).apply()
}
