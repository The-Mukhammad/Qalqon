package app.qalqon

import android.telecom.Call
import android.telecom.CallScreeningService

class CallFilteringService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        var response = CallScreeningService.CallResponse.Builder().build() // default: let the call through
        try {
            if (details.callDirection == Call.Details.DIRECTION_INCOMING) {
                val number = details.handle?.schemeSpecificPart
                val d = Matcher.decide(this, number)
                if (d.block) {
                    val silence = Prefs.bool(this, Prefs.SILENCE, false)
                    val hide = Prefs.bool(this, Prefs.HIDE, false)
                    val b = CallScreeningService.CallResponse.Builder()
                    if (silence) {
                        b.setSilenceCall(true)
                    } else {
                        b.setDisallowCall(true).setRejectCall(true)
                        if (hide) b.setSkipCallLog(true).setSkipNotification(true)
                    }
                    response = b.build()
                    Db.get(this).addLog(number, d.reason)
                    Notifier.blocked(this, number)
                }
            }
        } catch (e: Exception) {
            // never block a call because of our own error
        }
        respondToCall(details, response)
    }
}
