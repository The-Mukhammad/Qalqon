package app.qalqon

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Rule(
    val id: Long,
    val number: String,
    val name: String?,
    val mtype: Int,
    val white: Boolean,
    val enabled: Boolean
)

data class LogItem(val id: Long, val number: String?, val time: Long, val reason: String)

data class Period(val id: Long, val day: Int, val startMin: Int, val endMin: Int, val enabled: Boolean)

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "qalqon.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE rules(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT NOT NULL, " +
                "name TEXT, mtype INTEGER NOT NULL, white INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)"
        )
        db.execSQL(
            "CREATE TABLE log(id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, time INTEGER NOT NULL, reason TEXT)"
        )
        db.execSQL(
            "CREATE TABLE periods(id INTEGER PRIMARY KEY AUTOINCREMENT, day INTEGER NOT NULL, " +
                "startMin INTEGER NOT NULL, endMin INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---- rules ----
    fun rules(white: Boolean, onlyEnabled: Boolean = false): List<Rule> {
        val out = ArrayList<Rule>()
        val sql = "SELECT id, number, name, mtype, white, enabled FROM rules WHERE white=?" +
            (if (onlyEnabled) " AND enabled=1" else "") + " ORDER BY id DESC"
        readableDatabase.rawQuery(sql, arrayOf(if (white) "1" else "0")).use { c ->
            while (c.moveToNext()) {
                out.add(Rule(c.getLong(0), c.getString(1), c.getString(2), c.getInt(3), c.getInt(4) == 1, c.getInt(5) == 1))
            }
        }
        return out
    }

    fun addRule(number: String, name: String?, mtype: Int, white: Boolean): Boolean {
        val n = number.trim()
        if (Matcher.norm(n).isEmpty()) return false
        val w = if (white) "1" else "0"
        readableDatabase.rawQuery(
            "SELECT 1 FROM rules WHERE number=? AND mtype=? AND white=?",
            arrayOf(n, mtype.toString(), w)
        ).use { if (it.moveToFirst()) return false }
        val v = ContentValues()
        v.put("number", n)
        v.put("name", name?.trim())
        v.put("mtype", mtype)
        v.put("white", if (white) 1 else 0)
        v.put("enabled", 1)
        return writableDatabase.insert("rules", null, v) != -1L
    }

    fun setRuleEnabled(id: Long, enabled: Boolean) {
        val v = ContentValues()
        v.put("enabled", if (enabled) 1 else 0)
        writableDatabase.update("rules", v, "id=?", arrayOf(id.toString()))
    }

    fun deleteRule(id: Long) {
        writableDatabase.delete("rules", "id=?", arrayOf(id.toString()))
    }

    fun clearRules(white: Boolean) {
        writableDatabase.delete("rules", "white=?", arrayOf(if (white) "1" else "0"))
    }

    // ---- log ----
    fun addLog(number: String?, reason: String) {
        val v = ContentValues()
        v.put("number", number)
        v.put("time", System.currentTimeMillis())
        v.put("reason", reason)
        val db = writableDatabase
        db.insert("log", null, v)
        db.execSQL("DELETE FROM log WHERE id NOT IN (SELECT id FROM log ORDER BY id DESC LIMIT 1000)")
    }

    fun logs(): List<LogItem> {
        val out = ArrayList<LogItem>()
        readableDatabase.rawQuery("SELECT id, number, time, reason FROM log ORDER BY id DESC LIMIT 300", null).use { c ->
            while (c.moveToNext()) out.add(LogItem(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3) ?: ""))
        }
        return out
    }

    fun countLog(since: Long): Int {
        return readableDatabase.rawQuery("SELECT COUNT(*) FROM log WHERE time>=?", arrayOf(since.toString())).use {
            if (it.moveToFirst()) it.getInt(0) else 0
        }
    }

    fun clearLog() {
        writableDatabase.delete("log", null, null)
    }

    // ---- schedule ----
    fun periods(): List<Period> {
        val out = ArrayList<Period>()
        readableDatabase.rawQuery("SELECT id, day, startMin, endMin, enabled FROM periods ORDER BY day, startMin", null).use { c ->
            while (c.moveToNext()) out.add(Period(c.getLong(0), c.getInt(1), c.getInt(2), c.getInt(3), c.getInt(4) == 1))
        }
        return out
    }

    fun addPeriod(day: Int, startMin: Int, endMin: Int) {
        val v = ContentValues()
        v.put("day", day)
        v.put("startMin", startMin)
        v.put("endMin", endMin)
        v.put("enabled", 1)
        writableDatabase.insert("periods", null, v)
    }

    fun deletePeriod(id: Long) {
        writableDatabase.delete("periods", "id=?", arrayOf(id.toString()))
    }

    companion object {
        @Volatile
        private var inst: Db? = null

        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Db(c.applicationContext).also { inst = it }
        }
    }
}
